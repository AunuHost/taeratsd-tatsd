//npm i fake-useragent request url tls http http2 cloudscraper randomstring events cluster net fs crypto colors node-telegram-bot-api gradient-string requests axios telegraf express child_process

salin dan tempel di terminal untuk instal module